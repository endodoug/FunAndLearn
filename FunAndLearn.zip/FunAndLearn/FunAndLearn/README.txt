Requires Swift 2.0.
Build with Xcode 7.
See ‘Documentation.txt’ for details.